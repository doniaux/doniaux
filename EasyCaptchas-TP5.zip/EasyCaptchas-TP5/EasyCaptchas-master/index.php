<!doctype>
<html>
<head>
<meta charset="UTF-8"/>
</head>


<?php

/* SCRIPT FRONTAL AFFICHAGE DE CAPTCHA
* AFFICHER UNE IMAGE G�N�R�E EN PHP */

echo "<img src='script-captchas.php' alt='captchas'/>";

?>
<body>
<p>
<input type="text" id="name" name="name" required
       minlength="5" maxlength="5" size="10" align="right>
	   
<form name="form" method="post" action="">
<input type="submit" value="VALIDER" name="VALIDER">

</form>

</html>