<?php

/* SCRIPT FRONTAL AFFICHAGE DE CAPTCHA
* AFFICHER UNE IMAGE G�N�R�E EN PHP */

echo "<img src='script-captchas.php' alt='captchas' />";

?>